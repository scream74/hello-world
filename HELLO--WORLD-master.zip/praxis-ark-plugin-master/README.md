# Praxis Client and Praxis Developer - ARK Desktop Wallet plugin
Use Praxis client and Praxis Developer directly in the wallet 

## Installation

 1. Drop this repository into `~/.ark-desktop/plugins/`.
 2. Start the desktop wallet.
 3. Enable the plugin on the plugin section.

## Credits

- [Bill Donahue](https://github.com/incentum)

## License

[MIT](LICENSE) © [Incentum Ltd](https://incentum.network)
